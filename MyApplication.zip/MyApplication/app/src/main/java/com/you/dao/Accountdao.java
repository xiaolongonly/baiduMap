package com.you.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.you.bean.User;
import com.you.db.DBHelper;

/**
 * Created by Administrator on 2015/7/29.
 */
public class Accountdao {
    String TABLE_NAME="users";
    DBHelper helper = null;
    Cursor cursor;
    public Accountdao(Context cxt) {
        helper = new DBHelper(cxt);
    }

    /**
     * 当Activity中调用此构造方法，传入一个版本号时，系统会在下一次调用数据库时调用Helper中的onUpgrade()方法进行更新
     * @param cxt
     * @param version
     */
    public Accountdao(Context cxt, int version) {
        helper = new DBHelper(cxt, version);
    }
    // 插入操作 
    public void insertAccount(User user) {
        ContentValues values = new ContentValues();
        values.put("userid", user.getUserid().toString());
        values.put("account", user.getAccount().toString());
        values.put("password", user.getPassword().toString());
        SQLiteDatabase db =helper.getWritableDatabase();
        db.insert(TABLE_NAME, null, values);
        db.close();
    }
    // 查询操作  获取第一个帐号这里我们也只要一个帐号
    public User getAcoount()
    {
        SQLiteDatabase db =helper.getWritableDatabase();
        cursor =db.query(TABLE_NAME,null,null,null,null,null,null);
        User user =new User();
        if(cursor.getCount()>0)
        {
        	cursor.moveToNext();
        	user.setUserid(Integer.valueOf(cursor.getString(0)));
        	user.setAccount(cursor.getString(1));
        	user.setPassword(cursor.getString(2));
        }
        else
        {
        	user.setUserid(0);
        	user.setAccount("");
        	user.setPassword(""	);
        }
        return user;
    }
    //删除操作
    public void clean()
    {
        SQLiteDatabase db =helper.getWritableDatabase();
        db.delete(TABLE_NAME,"userid is not null",null);
        db.close();
    }
}
