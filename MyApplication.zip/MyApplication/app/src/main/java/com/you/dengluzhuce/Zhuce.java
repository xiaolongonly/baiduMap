package com.you.dengluzhuce;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.codehaus.jackson.map.ObjectMapper;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.provider.MediaStore.MediaColumns;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.you.bean.User;
import com.you.daoimpl.IUserService;
import com.you.registerUtil.IdentifyCode.makeCertPic;
import com.you.registerUtil.Img.CircleImg;
import com.you.registerUtil.Img.Picstr;
import com.you.registerUtil.Img.SelectPicPopupWindow;


/**
 * Created by zjm on 15-7-23.
 */
public class Zhuce extends Activity implements OnClickListener{

    private CircleImg avatarImg;// 头像图片
    private EditText username;//用户名
    private EditText telnum;//电话号码
    private EditText email;//邮箱框
    private EditText password;//密码框
    private EditText repassword;//确认密码框
    private EditText identify_code;//验证码输入框
    private Button changeBtn; //换验证码
    private CheckBox agreementCb;//协议
    private ImageView identify_img;//验证码图片
    private SelectPicPopupWindow menuWindow; // 自定义的头像编辑弹出框
    private Uri photoUri;
    private Button backBtn;
    private Button registerBtn;
    private TextView titleTxt;
    private Context mcontext;
    /** 使用照相机拍照获取图片 */
    public static final int SELECT_PIC_BY_TACK_PHOTO = 1;
    /** 使用相册中的图片 */
    public static final int SELECT_PIC_BY_PICK_PHOTO = 2;
    /** 获取到的图片路径 */
    private String bitName = "headpic";//剪裁后图片名称
    private String picPath = "";
    private String pictostr = "";
    private static ProgressDialog pd;
    private String resultStr = "";	// 服务端返回结果集
    private int resultCode;
    private String imgUrl = "";
    private String serverUrl = "http://localhost:8080/ServiceTest/Picutil_Servlet";
    private makeCertPic code =new makeCertPic();
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        setContentView(R.layout.zhuce);
        getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.custom_title_bar);
        mcontext = Zhuce.this;
        initViews();
    }

    /**
     * 初始化界面
     */
    private void initViews(){
        avatarImg =(CircleImg)findViewById(R.id.avatarImg);
        username =(EditText) findViewById(R.id.user_edit);
        password=(EditText)findViewById(R.id.pass_edit);
        telnum=(EditText)findViewById(R.id.tele_edit);
        email =(EditText)findViewById(R.id.email_edit);
        repassword=(EditText)findViewById(R.id.repass_edit);
        identify_code =(EditText)findViewById(R.id.identify_edit);
        identify_img =(ImageView)findViewById(R.id.identify_img);
        identify_img.setImageBitmap(code.getInstance().createBitmap());//验证码
        identify_img.setOnClickListener(this);//点击切换验证码监听
        agreementCb=(CheckBox)findViewById(R.id.xieyi_cb);//
        agreementCb.setOnClickListener(this);//协议CheckBox监听
        avatarImg.setOnClickListener(this);//头像按钮点击事件监听.
        backBtn = (Button) findViewById(R.id.back_Btn);
        backBtn.setOnClickListener(this);
        registerBtn = (Button) findViewById(R.id.funBtn);
        titleTxt = (TextView) findViewById(R.id.titleTxt);
        registerBtn.setOnClickListener(this);//提交按钮监听
    }
    //这里是按钮点击事件的处理
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.identify_img://切换验证码
                changedefcodeEvent();
                break;
            case R.id.xieyi_cb:// 协议点击事件
                agreejudgeEvent();
                break;
            case R.id.avatarImg:// 点击头像
                // 从页面底部弹出一个窗体，选择拍照还是从相册选择已有图片
                menuWindow = new SelectPicPopupWindow(Zhuce.this, itemsOnClick);
                menuWindow.showAtLocation(findViewById(R.id.zhuceLayout), //这里的zhucelayout 是当前activity的id 在当前窗口显示
                        Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL, 0, 0);
                break;
            case R.id.funBtn://提交
                submitEvent();
                break;
            case R.id.back_Btn: //返回前一个页面
            	Intent in=getIntent();
            	//设置返回结果成功
            	setResult(RESULT_OK, in);
            	//关闭当前activity
            	finish();
                break;
            default:
                break;
        }
    }
	//为弹出窗口实现监听类
    private OnClickListener itemsOnClick = new OnClickListener() {
        @Override
        public void onClick(View v) {
            // 隐藏弹出窗口
            switch (v.getId()) {
                case R.id.takePhotoBtn:// 拍照
                    takePhoto();
                    break;
                case R.id.pickPhotoBtn:// 相册选择图片
                    pickPhoto();
                    break;
                case R.id.cancelBtn:// 取消
                    break;
                default:
                    break;
            }
            menuWindow.dismiss();
        }

    };
    /**
     * 拍照获取图片
     */
    private void takePhoto() {
        // 执行拍照前，应该先判断SD卡是否存在
        String SDState = Environment.getExternalStorageState();
        if (SDState.equals(Environment.MEDIA_MOUNTED)) {

            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            /***
             * 需要说明一下，以下操作使用照相机拍照，拍照后的图片会存放在相册中的
             * 这里使用的这种方式有一个好处就是获取的图片是拍照后的原图
             * 如果不使用ContentValues存放照片路径的话，拍照后获取的图片为缩略图不清晰
             */
            ContentValues values = new ContentValues();
            photoUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, photoUri);
            startActivityForResult(intent, SELECT_PIC_BY_TACK_PHOTO);
        } else {
            Toast.makeText(this, "内存卡不存在", Toast.LENGTH_LONG).show();
        }
    }
    /***
     * 从相册中取图片
     */
    private void pickPhoto() {
        Intent intent = new Intent();
        // 如果要限制上传到服务器的图片类型时可以直接写如："image/jpeg 、 image/png等的类型"
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, SELECT_PIC_BY_PICK_PHOTO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // 点击取消按钮
        if(resultCode == RESULT_CANCELED){
            return;
        }

        // 可以使用同一个方法，这里分开写为了防止以后扩展不同的需求
        switch (requestCode) {
            case SELECT_PIC_BY_PICK_PHOTO:// 如果是直接从相册获取
                doPhoto(requestCode, data);
                break;
            case SELECT_PIC_BY_TACK_PHOTO:// 如果是调用相机拍照时
                doPhoto(requestCode, data);
                break;
            case 0:
    			try {
    				getImageToView(data);
    			} catch (IOException e) {
    				// TODO 自动生成的 catch 块
    				e.printStackTrace();
    			}
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    /**
     * 选择图片后，获取图片的路径
     *
     * @param requestCode
     * @param data
     */
    private void doPhoto(int requestCode, Intent data) {

        // 从相册取图片，有些手机有异常情况，请注意
        if (requestCode == SELECT_PIC_BY_PICK_PHOTO) {
            if (data == null) {
                Toast.makeText(this, "选择图片文件出错", Toast.LENGTH_LONG).show();
                return;
            }
            photoUri = data.getData();
            if (photoUri == null) {
                Toast.makeText(this, "选择图片文件出错", Toast.LENGTH_LONG).show();
                return;
            }
        }

        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(photoUri, "image/*");
        // 设置裁剪
        intent.putExtra("crop", "true");
        // aspectX aspectY 是宽高的比例
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // outputX outputY 是裁剪图片宽高
        intent.putExtra("outputX", 80);
        intent.putExtra("outputY", 80);
        intent.putExtra("return-data", true);
        startActivityForResult(intent,0); 
    }
    /**
     * 写一个changedefcode 方法用来验证码切换
     */
    public void changedefcodeEvent(){
        identify_img.setImageBitmap(code.getInstance().createBitmap());
    }
    /**
     * 写一个协议判断的方法
     */
    public void agreejudgeEvent() {
        if(agreementCb.isChecked()==true) {
        new AlertDialog.Builder(Zhuce.this)
                .setTitle("提示框")
                .setMessage("这是一条提示")
                .setPositiveButton("确定", null)
                .show();
    }
    }
    /**
     * 保存裁剪之后的图片数据
     *
     * @param picdata
     */
    private void getImageToView(Intent data) throws IOException{
    	  Bundle extras = data.getExtras();
          if (extras != null) {
              Bitmap photo = extras.getParcelable("data");
              pictostr = Picstr.convertIconToString(photo);
              File f =new File(getFilesDir()+File.separator+bitName+".png");//讲头像图片存放到指定路径中
              f.createNewFile();
              FileOutputStream fOut=null;
              try
              {
            	  fOut =new FileOutputStream(f);
            	  
              }
              catch(FileNotFoundException e)
              {
            	  e.printStackTrace();
              }
              photo.compress(Bitmap.CompressFormat.PNG,100,fOut);
              try
              {
            	  fOut.flush();
              }
              catch(IOException e)
              {
            	  e.printStackTrace();
              }
              try
              {
            	  fOut.close();
              }
              catch(IOException e)
              {
            	  e.printStackTrace();
              }
              //Drawable drawable = new BitmapDrawable(photo);
              //avatarImg.setImageDrawable(drawable);
              avatarImg.setImageBitmap(photo);//设置头像
              //将图片上传到服务器
             //pd = ProgressDialog.show(mContext, null, "正在上传图片，请稍候...");
             //new Thread(uploadImageRunnable).start();//调用子线程进行后续操作
          }
    }
    /**
  	 * 使用HttpUrlConnection模拟post表单进行文件
  	 * 上传平时很少使用，比较麻烦
  	 * 原理是： 分析文件上传的数据格式，然后根据格式构造相应的发送给服务器的字符串。
  	 */
  	Runnable uploadImageRunnable = new Runnable() {
  		@Override
  		public void run() {
  			
  			if(TextUtils.isEmpty(serverUrl)){
  				Toast.makeText(mcontext, "还没有设置上传服务器的路径！", Toast.LENGTH_SHORT).show();
  				return;
  			}
  			try {
  				// 创建一个URL对象
  				URL url = new URL(serverUrl);
  				pictostr = "image" +pictostr;
  				byte[] data =pictostr.getBytes("utf-8");
  				// 要上传的图片文件
  				HttpURLConnection conn= (HttpURLConnection) url.openConnection();
  				conn.setConnectTimeout(5000);
  				conn.setReadTimeout(5000);
  				conn.setDoOutput(true);
  				OutputStream out = conn.getOutputStream();
  				out.write(data);
  				out.flush();
  				resultCode =conn.getResponseCode();
  				if(resultCode!=200)
  				{
  					return;
  				}
  				ObjectMapper om =new ObjectMapper();//转为json流，还是没怎么懂
  				resultStr = om.readValue(conn.getInputStream(),String.class);
  				
  			} catch (Exception e) {
  				e.printStackTrace();
  			}
  			handler.sendEmptyMessage(0);// 执行耗时的方法之后发送消给handler
  		}
  	};
  	Handler handler = new Handler(new Handler.Callback() {

  		@Override
  		public boolean handleMessage(Message msg) {
  			switch (msg.what) {
  			case 0:
  				pd.dismiss();
  				//余下的操作
  				if(resultStr.equals(pictostr))
  				{
  					Log.i("response", "success");
  				}
  				break;
  			default:
  				break;
  			}
  			return false;
  		}
  	});
    
    /**
     * 写一个提交的方法放入子线程进行与服务器的交互
     */
    public void submitEvent() {
        if(code.getInstance().getCode().trim().equals(identify_code.getText().toString().trim())&&agreementCb.isChecked())//验证码正确
        {
            //向服务器发送注册信息
            //返回注册结果
            Toast.makeText(this,"注册成功,然而并没有真正注册成功。DB类没写完。", Toast.LENGTH_LONG).show();
            User user =new User(); 
            IUserService us =new IUserService();
            user.setHeadpic(BitmapFactory.decodeFile(picPath));
            user.setAccount(username.getText().toString().trim());
            user.setPassword(password.getText().toString().trim());
            user.setTelnum(telnum.getText().toString().trim());
            user.setEmail(email.getText().toString().trim());
            us.Adduser(user);
            Intent intent = new Intent(Zhuce.this, MainActivity.class);//
            startActivity(intent);
        }
        else
        {
            Toast.makeText(this,"请输入完整的信息!!", Toast.LENGTH_LONG).show();
        }
    }
}
