package com.you.bean;

import android.graphics.Bitmap;

/**
 * 用户注册信息实体
 * Created by Administrator on 2015/7/28.
 */
public class User {
    private Integer userid;
    private String nickname;
    private String account;
    private String password;
    private String telnum;
    private String email;
    private Bitmap headpic;
    private String userintroduction;
    private Integer schoolid;
    private String createTime;

    /**
     * 注册的构造函数
     * @param nickname
     * @param account
     * @param password
     * @param telnum
     * @param email
     * @param headpic
     */
    public User( String nickname, String account, String password, String telnum, String email, Bitmap headpic) {
        this.nickname = nickname;
        this.account = account;
        this.password = password;
        this.telnum = telnum;
        this.email = email;
        this.headpic = headpic;
    }

    /**
     * 帐号密码登录验证
     * @param userid
     * @param account
     * @param password
     */
    public User(Integer userid, String account, String password) {
        this.userid = userid;
        this.account = account;
        this.password = password;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTelnum() {
        return telnum;
    }

    public void setTelnum(String telnum) {
        this.telnum = telnum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Bitmap getHeadpic() {
        return headpic;
    }

    public void setHeadpic(Bitmap headpic) {
        this.headpic = headpic;
    }

    public String getUserintroduction() {
        return userintroduction;
    }

    public void setUserintroduction(String userintroduction) {
        this.userintroduction = userintroduction;
    }

    public Integer getSchoolid() {
        return schoolid;
    }

    public void setSchoolid(Integer schoolid) {
        this.schoolid = schoolid;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    /**
     * 用户信息获取的构造函数
     * @param userid
     * @param telnum
     * @param nickname
     * @param email
     * @param headpic
     * @param userintroduction
     * @param createTime
     * @param schoolid
     */
    public User(Integer userid, String telnum, String nickname, String email, Bitmap headpic, String userintroduction, String createTime, Integer schoolid) {
        this.userid = userid;
        this.telnum = telnum;
        this.nickname = nickname;
        this.email = email;
        this.headpic = headpic;
        this.userintroduction = userintroduction;
        this.createTime = createTime;
        this.schoolid = schoolid;
    }

    /**
     * 所有参数 测试数据用
     * @param userid
     * @param nickname
     * @param account
     * @param password
     * @param telnum
     * @param email
     * @param headpic
     * @param userintroduction
     * @param schoolid
     * @param createTime
     */
    public User(Integer userid, String nickname, String account, String password, String telnum, String email, Bitmap headpic, String userintroduction, Integer schoolid, String createTime) {
        this.userid = userid;
        this.nickname = nickname;
        this.account = account;
        this.password = password;
        this.telnum = telnum;
        this.email = email;
        this.headpic = headpic;
        this.userintroduction = userintroduction;
        this.schoolid = schoolid;
        this.createTime = createTime;
    }

    public User() {
    }
}