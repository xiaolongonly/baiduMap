package com.you.daoimpl;

import com.you.bean.User;

/**
 * 这个是模拟服务器的类。 好吧。。 Adduser那个没写好 数组会越界。 = =不想试了。反正是服务器的事情。
 * Created by Administrator on 2015/7/28.
 */
public class IUserService {
    private User[] users={new User(1,"张三","719243738","a6823192","6823192","719243738@qq.com",null,"我是一个大帅比",null,null)};
    /**
     * 通过userid获取user信息
     * @param userid
     * @return
     */
    public User getUserInfoById(int userid){
        User user =new User();
        for(int i=0;i<users.length;i++)
        {
            if(users[i].getUserid().equals(userid))
            {
                user.setNickname(users[i].getNickname());//昵称
                user.setEmail(users[i].getEmail());//邮箱
                user.setHeadpic(users[i].getHeadpic());//头像
                user.setTelnum(users[i].getTelnum());//电话
                user.setSchoolid(users[i].getSchoolid());//学校id
                user.setUserintroduction(users[i].getUserintroduction());//描述
                user.setCreateTime(users[i].getCreateTime());
                break;
            }
        }
        return user;
    }

    /**
     * 添加User实体
     * @param user
    */
    public void Adduser(User user){
        users[2].setUserid(2);
        users[2]=user;
}

    /**
     * 通过Id 来修改user信息
     * @param userid
     */
    public void UpdateUserInfo(Integer userid) {

    }


    /**
     * 用来获取登录账户的id 有id返回就是账户存在
     * @param account
     * @param password
     * @return
     */
    public Integer getUserIdByAcandPs(String account,String password)
    {
        Integer userid=null;
        for(int i=0;i<users.length;i++)
        {
            if(users[i].getAccount().equals(account)&&users[i].getPassword().equals(password))
            {
                userid=users[i].getUserid();
                break;
            }
        }
        return userid;
    }
}
