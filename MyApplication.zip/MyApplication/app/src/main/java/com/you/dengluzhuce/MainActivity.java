package com.you.dengluzhuce;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.you.bean.User;
import com.you.dao.Accountdao;
import com.you.daoimpl.IUserService;
public class MainActivity extends Activity implements OnClickListener {

    private TextView register,forgotpsw;
    private Button exit,login;
    private EditText account,password;
    private ImageView head;
    Accountdao ad= new Accountdao(MainActivity.this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.login_layout);
        initViews();
    }
    public void initViews()
    {
        login =(Button)findViewById(R.id.btlogin);
        login.setOnClickListener(this);
        exit =(Button)findViewById(R.id.btexit);
        exit.setOnClickListener(this);;
        User user =ad.getAcoount();
        account=(EditText)findViewById(R.id.etusn);
        password=(EditText)findViewById(R.id.etpsw);
        register=(TextView)findViewById(R.id.tvregister);
        register.setOnClickListener(this);
        forgotpsw=(TextView)findViewById(R.id.tvfgpsw);
        forgotpsw.setOnClickListener(this);
        head=(ImageView)findViewById(R.id.ivhead);
        if(user.getAccount().length()>0)
        {
            account.setText(user.getAccount().toString());
            password.setText(user.getPassword().toString());
        }
    }
    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btlogin://登陆
                login();
                break;
            case R.id.btexit:// 退出
                this.finish();
                break;
            case R.id.tvregister: //注册
                Intent intent = new Intent(MainActivity.this, Zhuce.class);
                startActivity(intent);
                break;
            case R.id.tvfgpsw://忘记密码
            default:
                break;
        }
    }
        /**
         * 登陆事件处理
         */
    public void login()
    {
        IUserService us=new IUserService();
        User user =new User();
        user.setAccount(account.getText().toString().trim());
        user.setPassword(password.getText().toString().trim());
        Integer id =us.getUserIdByAcandPs(user.getAccount(),user.getPassword());
        if(id!=null)
        {
            Toast.makeText(this, "登陆成功", Toast.LENGTH_LONG).show();
            user.setUserid(id);
            ad.clean();
            ad.insertAccount(user);
        }
        else
        {
            Toast.makeText(this, "用户名或密码错误", Toast.LENGTH_LONG).show();
        }
    }

}
